package com.example.farmersnet.chatRooms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.farmersnet.R;

public class ChatRoomPageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_room_page);
    }
}
