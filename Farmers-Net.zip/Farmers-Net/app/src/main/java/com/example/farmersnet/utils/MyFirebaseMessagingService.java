package com.example.farmersnet.utils;

public class MyFirebaseMessagingService extends FirebaseMess {
}
